import { SafeAreaView, StatusBar } from "react-native"
import LoginScreen from "./components/LoginScreen"

export default function App() {
  const handleLogin = async (email: string, password: string) => {
    // Implement your login logic here
    console.log("Login attempt:", { email, password })
    // You can integrate with your authentication service here
  }

  const handleSignUp = async (email: string, password: string) => {
    // Implement your sign up logic here
    console.log("Sign up attempt:", { email, password })
    // You can integrate with your authentication service here
  }

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      <LoginScreen onLogin={handleLogin} onSignUp={handleSignUp} />
    </SafeAreaView>
  )
}
